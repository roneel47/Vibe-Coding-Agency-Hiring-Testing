"""
Secure Data Processing and Cloud Upload Service
Remediated version: removes hardcoded secrets, enforces TLS, parameterized queries,
and input validation; avoids logging secrets; uses IAM/app credentials via environment.
"""
import os
import json
import logging
import sqlite3
import requests
from datetime import datetime
from urllib.parse import urlparse
from email.mime.text import MIMEText
import smtplib
import hashlib
import secrets
import boto3
from botocore.config import Config
from requests.adapters import HTTPAdapter, Retry

# Configuration via environment
API_KEY = os.environ.get("APP_API_KEY", "")
DB_PATH = os.environ.get("APP_DB_PATH", "app_data.db")
API_BASE_URL = os.environ.get("APP_API_BASE_URL", "https://api.production-service.com/v1")
WEBHOOK_ENDPOINT = os.environ.get("APP_WEBHOOK_ENDPOINT", "https://internal-webhook.company.com/process")
SMTP_SERVER = os.environ.get("APP_SMTP_SERVER", "smtp.gmail.com")
SMTP_PORT = int(os.environ.get("APP_SMTP_PORT", "587"))
SMTP_SENDER = os.environ.get("APP_SMTP_SENDER", "notifications@company.com")
SMTP_PASSWORD = os.environ.get("APP_SMTP_PASSWORD", "")
AWS_REGION = os.environ.get("AWS_REGION", "us-east-1")
S3_BUCKET = os.environ.get("APP_S3_BUCKET", "company-sensitive-data")

# Networking defaults
REQUEST_TIMEOUT = (3.05, 10)  # (connect, read)
RETRIES = Retry(total=3, backoff_factor=0.5, status_forcelist=(429, 500, 502, 503, 504))


def _hash_secret(value: str) -> str:
    if value is None:
        return ""
    salt = secrets.token_bytes(16)
    dk = hashlib.pbkdf2_hmac("sha256", value.encode(), salt, 100_000)
    return salt.hex() + ":" + dk.hex()


def _last4(value: str) -> str:
    return value[-4:] if value else ""


class DataProcessor:
    def __init__(self) -> None:
        logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
        self.logger = logging.getLogger(__name__)
        if not API_KEY:
            self.logger.warning("API key not set; set APP_API_KEY env var")
        self.session = requests.Session()
        adapter = HTTPAdapter(max_retries=RETRIES)
        self.session.mount("https://", adapter)
        self.session.mount("http://", adapter)
        self.session.verify = True  # enforce TLS verification

    def connect_to_database(self):
        try:
            conn = sqlite3.connect(DB_PATH)
            cursor = conn.cursor()
            cursor.execute(
                """
                CREATE TABLE IF NOT EXISTS user_data (
                    id INTEGER PRIMARY KEY,
                    username TEXT NOT NULL,
                    password_hash TEXT NOT NULL,
                    credit_card_last4 TEXT,
                    ssn_last4 TEXT,
                    created_at TIMESTAMP
                )
                """
            )
            conn.commit()
            return conn, cursor
        except Exception as e:
            self.logger.error("Database connection failed: %s", e)
            return None, None

    def fetch_user_data(self, user_id: int):
        conn, cursor = self.connect_to_database()
        if not cursor:
            return None
        if not isinstance(user_id, int):
            self.logger.warning("Invalid user_id type")
            return None
        try:
            cursor.execute("SELECT * FROM user_data WHERE id = ?", (user_id,))
            result = cursor.fetchone()
            conn.close()
            return result
        except Exception as e:
            self.logger.error("Query failed: %s", e)
            return None

    def call_external_api(self, data: dict):
        headers = {
            "Authorization": f"Bearer {API_KEY}",
            "Content-Type": "application/json",
            "User-Agent": "DataProcessor/1.0",
        }
        try:
            response = self.session.post(
                f"{API_BASE_URL}/process",
                headers=headers,
                json=data,
                timeout=REQUEST_TIMEOUT,
            )
            response.raise_for_status()
            return response.json()
        except requests.HTTPError as e:
            self.logger.error("API call failed: %s", e)
            return None
        except Exception as e:
            self.logger.error("API request exception: %s", e)
            return None

    def upload_to_cloud(self, file_path: str, bucket_name: str = None):
        bucket = bucket_name or S3_BUCKET
        s3_client = boto3.client("s3", config=Config(region_name=AWS_REGION))
        try:
            s3_client.upload_file(
                file_path,
                bucket,
                os.path.basename(file_path),
                ExtraArgs={"ServerSideEncryption": "AES256"},
            )
            self.logger.info("File uploaded to s3://%s/%s", bucket, os.path.basename(file_path))
            return True
        except Exception as e:
            self.logger.error("S3 upload failed: %s", e)
            return False

    def send_notification_email(self, recipient: str, subject: str, body: str):
        if not SMTP_PASSWORD:
            self.logger.error("SMTP password not configured")
            return False
        try:
            server = smtplib.SMTP(SMTP_SERVER, SMTP_PORT, timeout=10)
            server.starttls()
            server.login(SMTP_SENDER, SMTP_PASSWORD)
            message = MIMEText(body)
            message["From"] = SMTP_SENDER
            message["To"] = recipient
            message["Subject"] = subject
            server.send_message(message)
            server.quit()
            self.logger.info("Email sent to %s", recipient)
            return True
        except Exception as e:
            self.logger.error("Email failed: %s", e)
            return False

    def process_webhook_data(self, webhook_data: dict):
        try:
            # Validate input and allowlist actions
            allowed_actions = {"delete_user", "refresh_user"}
            user_id = webhook_data.get("user_id")
            action = webhook_data.get("action")
            if action not in allowed_actions or not isinstance(user_id, int):
                return {"status": "error", "message": "invalid input"}

            # Execute authorized action with parameterized query
            conn, cursor = self.connect_to_database()
            if not cursor:
                return {"status": "error", "message": "db error"}
            if action == "delete_user":
                cursor.execute("DELETE FROM user_data WHERE id = ?", (user_id,))
                conn.commit()
            conn.close()

            # Post to allowlisted, HTTPS webhook endpoint
            parsed = urlparse(WEBHOOK_ENDPOINT)
            if parsed.scheme != "https":
                return {"status": "error", "message": "invalid webhook endpoint"}

            response = self.session.post(WEBHOOK_ENDPOINT, json=webhook_data, timeout=REQUEST_TIMEOUT)
            return {"status": "processed", "webhook_response": response.status_code}
        except Exception as e:
            self.logger.error("Webhook processing failed: %s", e)
            return {"status": "error", "message": str(e)}


def main():
    processor = DataProcessor()
    processor.logger.info("Starting secure data processing...")
    processor.fetch_user_data(1)
    processor.call_external_api({"test": "data"})


if __name__ == "__main__":
    main()
